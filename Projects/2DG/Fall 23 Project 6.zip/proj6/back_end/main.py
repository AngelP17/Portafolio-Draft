from typing import Mapping, Any, List, Dict, Tuple
import os
from http_daemon import delay_open_url, serve_pages

class Player:
    def __init__(self, id: str) -> None:
        self.id = id
        self.x = 0
        self.y = 0
        self.what_i_know = 0

def find_player(player_id: str) -> Player:
    if player_id in players:
        return players[player_id]
    else:
        players[player_id] = Player(player_id)
        return players[player_id]
        
players: Dict[str, Player] = {}
history: List[Player] = []

def update(payload: Mapping[str, Any]) -> Mapping[str, Any]:
    action = payload["action"]
    if action == "ijustclicked":
        player = find_player(payload["id"])
        player.x = payload["x"]
        player.y = payload["y"]
        history.append(player)
    elif action == "iwantupdates":
        player = find_player(payload["id"])
        remaining_history = history[player.what_i_know:]
        player.what_i_know = len(history)
        updates: List[Tuple[str, int, int]] = [(p.id, p.x, p.y) for p in remaining_history]
        return {"updates": updates}
    return {'message': 'unknown action'}

def main() -> None:
    os.chdir(os.path.join(os.path.dirname(__file__), '../front_end'))
    port = 8987
    delay_open_url(f'http://localhost:{port}/game.html', 0.1)
    serve_pages(port, {'ajax.html': update})

if __name__ == "__main__":
    main()
