# Enable the script to stop on errors
$ErrorActionPreference = "Stop"

# Navigate to the front-end directory and type-check TypeScript code
Push-Location Downloads/proj6/front_end
Write-Host "Type-checking the front end"
tsc --strict --target esnext main.ts
Pop-Location

# Navigate to the back-end directory, type-check Python code, and run the server
Push-Location Downloads/proj6/back_end
Write-Host "Type-checking the back end"
python main.py --strict --ignore-missing-imports
Write-Host "Running Python server"
python3 main.py
Pop-Location

Write-Host "Done"
