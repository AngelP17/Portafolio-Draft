#!/bin/bash
set -e

# Navigate to the front-end directory and type-check TypeScript code
pushd front_end
echo "Type-checking the front end"
tsc --strict --target esnext main.ts
popd

# Navigate to the back-end directory, type-check Python code, and run the server
pushd back_end
echo "Type-checking the back end"
mypy main.py --strict --ignore-missing-imports
echo "Running Python server"
python3 main.py
popd

echo "Done"
