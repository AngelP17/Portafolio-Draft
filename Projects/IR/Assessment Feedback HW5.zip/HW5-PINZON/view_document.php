<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

if (isset($_GET['doc'])) {
    $doc_path = $_GET['doc'];
    // Check multiple possible locations
    $possible_paths = [
        $doc_path,
        "/home/ap436/hw4-2/files/" . basename($doc_path),
        "/home/ap436/public_html/search/files/" . basename($doc_path)
    ];

    $found = false;
    foreach ($possible_paths as $path) {
        if (file_exists($path)) {
            $doc_path = $path;
            $found = true;
            break;
        }
    }

    if (!$found) {
        die("Error: File not found: " . htmlspecialchars(basename($doc_path)));
    }

    $query = isset($_GET['query']) ? $_GET['query'] : '';
    
    ?>
    <!DOCTYPE html>
    <html>
    <head>
        <title>Document View - <?php echo htmlspecialchars(basename($doc_path)); ?></title>
        <style>
            * {
                margin: 0;
                padding: 0;
                box-sizing: border-box;
            }

            body {
                font-family: Arial, sans-serif;
                background-color: #f4f4f9;
                line-height: 1.6;
                color: #333;
            }

            .header {
                background-color: #f44336;
                color: white;
                text-align: center;
                padding: 20px;
                margin-bottom: 20px;
                box-shadow: 0 2px 4px rgba(0,0,0,0.1);
                position: relative;
            }

            .logo {
                position: absolute;
                left: 20px;
                top: 50%;
                transform: translateY(-50%);
                width: 50px;
                height: 50px;
            }

            h1 {
                font-size: 24px;
                font-weight: bold;
            }

            .document-container {
                max-width: 800px;
                margin: 20px auto;
                background: white;
                padding: 30px;
                border-radius: 8px;
                box-shadow: 0 2px 4px rgba(0,0,0,0.1);
            }

            .navigation {
                text-align: center;
                margin: 20px;
            }

            .back-button {
                background: #f44336;
                color: white;
                padding: 10px 20px;
                text-decoration: none;
                border-radius: 5px;
                display: inline-block;
                transition: background-color 0.3s;
            }

            .back-button:hover {
                background: #d32f2f;
            }

            .highlight {
                background-color: #fff176;
                padding: 2px;
                border-radius: 2px;
            }

            .document-content {
                white-space: pre-wrap;
                word-wrap: break-word;
                padding: 15px;
                font-size: 14px;
                line-height: 1.6;
            }

            .document-info {
                margin-bottom: 20px;
                padding-bottom: 10px;
                border-bottom: 1px solid #eee;
                color: #666;
            }

            .document-info strong {
                color: #333;
            }

            
            pre {
                white-space: pre-wrap;
                font-family: Arial, sans-serif;
                font-size: 14px;
            }

            table {
                border-collapse: collapse;
                width: 100%;
                margin: 10px 0;
            }

            td, th {
                padding: 8px;
                border: 1px solid #ddd;
            }

            
            .document-content a {
                color: #1a0dab;
                text-decoration: none;
            }

            .document-content a:hover {
                text-decoration: underline;
            }
        </style>
    </head>
    <body>
        <div class="header">
            <img src="logo.svg" alt="Logo" class="logo">
            <h1>Document Viewer</h1>
        </div>
        
        <div class="navigation">
            <a href="javascript:history.back()" class="back-button">← Back to Results</a>
        </div>

        <div class="document-container">
            <div class="document-info">
                <strong>File:</strong> <?php echo htmlspecialchars(basename($doc_path)); ?>
                <?php if (!empty($query)): ?>
                <br>
                <strong>Search Query:</strong> <?php echo htmlspecialchars($query); ?>
                <?php endif; ?>
            </div>
            
            <div class="document-content"><?php
                $content = file_get_contents($doc_path);
                
                if (!empty($query)) {
                    // Handle multi-word queries
                    $words = explode(' ', $query);
                    $content = htmlspecialchars($content);
                    
                    foreach ($words as $word) {
                        $word = trim($word);
                        if (!empty($word)) {
                            $content = preg_replace(
                                '/(' . preg_quote($word, '/') . ')/i',
                                '<span class="highlight">$1</span>',
                                $content
                            );
                        }
                    }
                } else {
                    $content = htmlspecialchars($content);
                }
                
                // Make URLs clickable
                $content = preg_replace(
                    '/(https?:\/\/[^\s<>"]+)/i',
                    '<a href="$1" target="_blank">$1</a>',
                    $content
                );
                
                echo $content;
            ?></div>
        </div>
    </body>
    </html>
    <?php
} else {
    header('Location: search.php');
    exit();
}
?>