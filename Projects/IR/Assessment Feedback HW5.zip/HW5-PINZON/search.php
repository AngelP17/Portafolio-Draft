<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

function print_form() {
    ?>
    <!DOCTYPE html>
    <html>
    <head>
        <title>Document Search Engine</title>
        <style>
            * {
                margin: 0;
                padding: 0;
                box-sizing: border-box;
            }

            body {
                font-family: Arial, sans-serif;
                background-color: #f4f4f9;
                color: #333;
                line-height: 1.6;
            }

            .header {
                background-color: #f44336;
                color: white;
                text-align: center;
                padding: 20px;
                position: relative;
                box-shadow: 0 2px 4px rgba(0,0,0,0.1);
            }

            .logo {
                position: absolute;
                left: 20px;
                top: 50%;
                transform: translateY(-50%);
                width: 90px;
                height: 90px;
                transition: transform 0.3s ease;
            }

            .logo:hover {
                transform: translateY(-50%) scale(1.05);
            }

            .title {
                font-size: 36px;
                font-weight: bold;
            }

            .search-container {
                text-align: center;
                margin: 40px auto;
                padding: 20px;
                max-width: 800px;
                background: white;
                border-radius: 8px;
                box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            }

            .search-box {
                width: calc(100% - 20px);
                max-width: 600px;
                padding: 15px;
                font-size: 16px;
                border: 1px solid #ccc;
                border-radius: 5px;
                margin-bottom: 20px;
                transition: border-color 0.3s, box-shadow 0.3s;
            }

            .search-box:focus {
                outline: none;
                border-color: #61D0F2;
                box-shadow: 0 0 0 3px rgba(97, 208, 242, 0.2);
            }

            .search-button {
                background-color: #61D0F2;
                color: white;
                border: none;
                padding: 12px 30px;
                font-size: 16px;
                border-radius: 5px;
                cursor: pointer;
                transition: background-color 0.3s;
                position: relative;
                overflow: hidden;
            }

            .search-button:hover {
                background-color: #4ab3d9;
            }

            .search-button:after {
                content: '';
                position: absolute;
                top: 0;
                left: -100%;
                width: 100%;
                height: 2px;
                background: rgba(255,255,255,0.5);
                animation: loading 1s infinite;
                display: none;
            }

            .search-button.loading:after {
                display: block;
            }

            @keyframes loading {
                from { left: -100%; }
                to { left: 100%; }
            }

            .example-queries {
                margin-top: 20px;
            }

            .example-queries a {
                color: #f44336;
                margin: 0 8px;
                cursor: pointer;
                text-decoration: none;
                transition: color 0.3s;
            }

            .example-queries a:hover {
                text-decoration: underline;
                color: #d32f2f;
            }

            .results {
                max-width: 800px;
                margin: 20px auto;
                background: white;
                padding: 20px;
                border-radius: 8px;
                box-shadow: 0 2px 4px rgba(0,0,0,0.1);
            }

            .results-header {
                background: #f44336;
                color: white;
                padding: 12px;
                margin: 20px 0 15px 0;
                border-radius: 5px;
                display: grid;
                grid-template-columns: 100px 100px auto;
                font-weight: bold;
                align-items: center;
                text-transform: uppercase;
                font-size: 14px;
                letter-spacing: 0.5px;
            }

            .result-item {
                display: grid;
                grid-template-columns: 100px 100px auto;
                padding: 12px;
                border-bottom: 1px solid #eee;
                align-items: center;
                transition: background-color 0.2s;
                box-shadow: 0 1px 2px rgba(0,0,0,0.05);
                margin: 2px 0;
                border-radius: 4px;
            }

            .result-item:hover {
                background-color: #f8f9fa;
            }

            .result-item:last-child {
                border-bottom: none;
            }

            .doc-id {
                font-weight: bold;
                color: #333;
            }

            .weight {
                font-family: monospace;
                color: #666;
            }

            .file-name a {
                color: #1a0dab;
                text-decoration: none;
                padding: 5px 0;
                display: inline-block;
                transition: color 0.2s;
            }

            .file-name a:after {
                content: ' ↗';
                font-size: 0.8em;
                color: #666;
                opacity: 0;
                transition: opacity 0.2s;
            }

            .file-name a:hover {
                text-decoration: underline;
                color: #1558d6;
            }

            .file-name a:hover:after {
                opacity: 1;
            }

            .processing-info {
                color: #555;
                margin-bottom: 10px;
                padding: 6px 10px;
                font-size: 13px;
                font-family: monospace;
                white-space: pre-wrap;
                line-height: 1.4;
                background: #f8f9fa;
                border-radius: 4px;
                border-left: 3px solid #f44336;
                margin: 4px 0;
            }

            h2 {
                text-align: center;
                color: #f44336;
                margin: 20px 0;
                font-size: 24px;
            }

            .search-results {
                margin-top: 30px;
            }

            .result-summary {
                background: #f8f9fa;
                padding: 15px;
                border-radius: 5px;
                margin-bottom: 20px;
                border-left: 4px solid #61D0F2;
            }

            .no-results {
                text-align: center;
                padding: 30px;
                color: #666;
                font-style: italic;
            }
        </style>
    </head>
    <body>
        <div class="header">
            <img src="logo.svg" alt="Logo" class="logo">
            <div class="title">DOCUMENT SEARCH ENGINE</div>
        </div>
        <div class="search-container">
            <form method="post">
                <input type="text" name="query" class="search-box" placeholder="Enter search query">
                <br>
                <button type="submit" class="search-button">Search</button>
            </form>
            <div class="example-queries">
                <p>Try these example queries:</p>
                <?php
                $examples = ['test', 'launch', 'vehicle', 'robot', 'honorary doctorate', 'Gauch'];
                foreach ($examples as $example) {
                    echo "<a onclick=\"document.querySelector('.search-box').value='$example';document.querySelector('form').submit();\">$example</a>";
                }
                ?>
            </div>
        </div>
    <?php
}

function execute_search($query) {
    $hw4_dir = '/home/ap436/hw4-2';
    $retrieve_path = "$hw4_dir/retrieve";
    $files_dir = "$hw4_dir/files";

    if (!is_dir($files_dir)) {
        echo "<div class='results'><p style='color: red;'>Error: Directory 'files' does not exist.</p></div>";
        return;
    }

    chdir($hw4_dir);
    $command = "$retrieve_path output " . escapeshellarg($query) . " 2>&1";
    $output = [];
    exec($command, $output, $return_var);

    echo "<div class='results'>";
    
    $in_results = false;
    $current_section = '';
    $has_results = false;
    
    foreach ($output as $line) {
        $clean_line = strip_tags($line);
        
        if (strpos($clean_line, 'No matching documents found.') !== false) {
            echo "<div class='no-results'>No documents found matching your query.</div>";
            continue;
        }
        
        if (strpos($clean_line, 'Top 10 Results:') !== false) {
            echo "<div class='results-header'>";
            echo "<div>Doc ID</div>";
            echo "<div>Weight</div>";
            echo "<div>Document Name</div>";
            echo "</div>";
            $in_results = true;
            continue;
        }
        
        if (!$in_results) {
            echo "<div class='processing-info'>" . htmlspecialchars($clean_line) . "</div>";
        } else {
            if (strpos($clean_line, 'DocIDWeightDocument Name') !== false) {
                continue;
            }
            
            if (preg_match('/^(\d+)$/', trim($clean_line), $matches)) {
                $current_section = 'docid';
                $current_docid = $matches[1];
                echo "<div class='result-item'>";
                echo "<div class='doc-id'>" . htmlspecialchars($current_docid) . "</div>";
                $has_results = true;
            } else if ($current_section == 'docid' && preg_match('/^([\d.]+)$/', trim($clean_line), $matches)) {
                $current_section = 'weight';
                echo "<div class='weight'>" . number_format((float)$matches[1], 4) . "</div>";
            } else if ($current_section == 'weight' && trim($clean_line) != '') {
                $current_section = '';
                $filename = trim($clean_line);
                echo "<div class='file-name'><a href='files/" . htmlspecialchars(basename($filename)) . 
                     "' target='_blank' onclick=\"window.open(this.href, 'fileViewer', 'width=800,height=600,scrollbars=yes'); return false;\">" . 
                     htmlspecialchars(basename($filename)) . "</a></div>";
                echo "</div>";
            }
        }
    }
    
    if (!$has_results && $in_results) {
        echo "<div class='no-results'>No matching documents found.</div>";
    }
    
    echo "</div>";
}

// Main execution
$query = isset($_POST['query']) ? $_POST['query'] : '';
print_form();
if (!empty($query)) {
    echo "<h2>Results for: " . htmlspecialchars($query) . "</h2>";
    execute_search($query);
}
?>
<script>
document.querySelector('form').addEventListener('submit', function() {
    document.querySelector('.search-button').classList.add('loading');
});
</script>
</body>
</html>