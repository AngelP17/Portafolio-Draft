import org.apache.spark.SparkContext
import org.apache.spark.SparkContext._
import org.apache.spark.SparkConf

object TemperatureAnalysis {

  def main(args: Array[String]): Unit = {
    val conf = new SparkConf().setAppName("TemperatureAnalysis")
    val sc = new SparkContext(conf)

    // Step 1: Load the temperature data
    val inputFile = "input.txt"
    val data = sc.textFile(inputFile)
      .map(line => {
        val parts = line.split("\\s+")
        // (City, (Date, Temperature))
        (parts(0), (parts(1), parts(2).toInt))
      })

    // Step 2: Calculate average, min, max, and standard deviation
    // TODO: Implement this step using combineByKey to calculate the following statistics for each city:
    // - Average temperature
    // - Minimum temperature
    // - Maximum temperature
    // - Standard deviation
    // 
    val cityStats = data.map { case (city, (_, temp)) => (city, temp) }
      .combineByKey(
        // Create combiner: Initial stats for one temperature
        (temp: Int) => (temp.toFloat, temp.toFloat * temp, temp, temp, 1L),
        
        // Merge value: Add a new temperature to existing stats
        (stats: (Float, Float, Int, Int, Long), temp: Int) => {
          val (sum, sumSq, min, max, count) = stats
          (
            sum + temp,
            sumSq + temp.toFloat * temp,
            math.min(min, temp),
            math.max(max, temp),
            count + 1
          )
        },
        
        // Merge combiners: Combine stats from different partitions
        (stats1: (Float, Float, Int, Int, Long), stats2: (Float, Float, Int, Int, Long)) => {
          val (sum1, sumSq1, min1, max1, count1) = stats1
          val (sum2, sumSq2, min2, max2, count2) = stats2
          (
            sum1 + sum2,
            sumSq1 + sumSq2,
            math.min(min1, min2),
            math.max(max1, max2),
            count1 + count2
          )
        }
      ).mapValues { case (sum, sumSq, min, max, count) =>
        val avg = sum / count
        val stdDev = math.sqrt(sumSq / count - avg * avg)
        (avg, min, max, stdDev)
      }
    // Suggested Approach:
    // - Use combineByKey to aggregate intermediate values: (sum, sum of squares, min, max, count).
    // - Use mapValues after combineByKey to compute the final statistics.
    //
    // val cityStats = ???
    
    // Step 3: Join temperature data with city statistics. 
    // cityStats - (City, (Average, Min, Max, StdDev))
    val statsRDD = cityStats.mapValues {
      case (avg, min, max, stdDev) =>
        (avg, stdDev)
    }

    // joinedData - (City, ((Date, Temperature), (Average, StdDev)))
    val joinedData = data.join(statsRDD)

    // Step 4: Identify anomalies
    val anomalies = joinedData.filter {
      case (_, ((_, temp), (avg, stdDev))) =>
        val lowerBound = avg - 2 * stdDev
        val upperBound = avg + 2 * stdDev
        temp < lowerBound || temp > upperBound
    }.map { case (city, ((date, temp), _)) =>
      (city, date, temp)
    }

    // Step 5: Save the results
    cityStats.map { case (city, (avg, min, max, stdDev)) =>
      s"$city $avg $min $max $stdDev"
    }.saveAsTextFile("output/stats")

    anomalies.map { case (city, date, temp) =>
      s"$city $date $temp"
    }.saveAsTextFile("output/anomalies")

    sc.stop()
  }
}
