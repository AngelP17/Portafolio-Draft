import java.util.*;
import org.apache.hadoop.io.Text;

public class Node {
    private final int id;
    private List<Integer> edges = new ArrayList<Integer>();
    private double mass;  // PageRank mass
    
    public Node(String str) {
        
        String[] map = str.split("\t");
        
        String key = map[0].trim();
        String value = map[1].trim();
        
        String[] tokens = value.split("\\|");
        this.id = Integer.parseInt(key);
        
        // Parse edges
        if (!tokens[0].equals("NULL")) {
            for (String s : tokens[0].split(",")) {
                if (s.length() > 0) {
                    edges.add(Integer.parseInt(s));
                }
            }
        }
        
        // Parse mass
        this.mass = Double.parseDouble(tokens[1]);
    }
    
    public Node(int id) {
        this.id = id;
    }
    
    public int getId() {
        return this.id;
    }
    
    public List<Integer> getEdges() {
        return this.edges;
    }
    
    public void setEdges(List<Integer> edges) {
        this.edges = edges;
    }
    
    public double getMass() {
        return this.mass;
    }
    
    public void setMass(double mass) {
        this.mass = mass;
    }
    
    public Text getLine() {
        StringBuilder s = new StringBuilder();
        
        // Append edges
        if (edges.isEmpty()) {
            s.append("NULL");
        } else {
            for (int v : edges) {
                s.append(v).append(",");
            }
            if (s.length() > 0) {
                s.setLength(s.length() - 1);  // Remove last comma
            }
        }
        s.append("|");
        
        // Append mass
        s.append(String.format("%.3f", mass));
        
        return new Text(s.toString());
    }
}