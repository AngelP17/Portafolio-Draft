import java.io.IOException;
import java.util.Iterator;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.conf.Configured;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapred.*;
import org.apache.hadoop.util.Tool;
import org.apache.hadoop.util.ToolRunner;

public class PageRank extends Configured implements Tool {
    private static int pass = 1;  // Global variable to track current pass
    private static int totalNodes = 0;  // Total number of nodes
    private static double alpha = 0.0;  // Random jump factor
    private static int iterations = 0;   // Number of iterations
    private static double missingMass = 0.0; 
    
    public static class MapClass extends MapReduceBase implements
            Mapper<LongWritable, Text, IntWritable, Text> {
                
        public void map(LongWritable key, Text value, OutputCollector<IntWritable, Text> output,
                Reporter reporter) throws IOException {
            
            Node node = new Node(value.toString());
            
            if (pass == 1) {
                // First pass: Distribute mass to neighbors
                double massToSend = node.getMass();
                if (!node.getEdges().isEmpty()) {
                    // If node has outgoing edges, distribute mass evenly
                    massToSend = node.getMass() / node.getEdges().size();
                    for (int edge : node.getEdges()) {
                        Node outNode = new Node(edge);
                        outNode.setMass(massToSend);
                        output.collect(new IntWritable(edge), outNode.getLine());
                    }
                }
                else{
                    missingMass += node.getMass(); 
                }
                
                // Emit original node with zero mass (structure preservation)
                node.setMass(0.0);
                output.collect(new IntWritable(node.getId()), node.getLine());
                
            } else {
                // Second pass: Apply random jump factor
                //double missingMass = (double)context.getCounter("PageRank", "MISSING_MASS").getValue()/ 1e6;
                //System.out.println("Missing Mass: " + missingMass);
                double adjustedMass = (1.0 - alpha) * (missingMass / totalNodes + node.getMass()) + (alpha / totalNodes); 
                node.setMass(adjustedMass);
                output.collect(new IntWritable(node.getId()), node.getLine());
            }
        }
    }
    
    public static class Reduce extends MapReduceBase implements
            Reducer<IntWritable, Text, IntWritable, Text> {
        
        public void reduce(IntWritable key, Iterator<Text> values,
                OutputCollector<IntWritable, Text> output, Reporter reporter) throws IOException {
            
            Node resultNode = null;
            double totalMass = 0.0;
            
            while (values.hasNext()) {
                Node node = new Node(key.get() + "\t" + values.next().toString());
                
                if (pass == 1) {
                    // First pass: Sum masses and preserve structure
                    totalMass += node.getMass();
                    if (!node.getEdges().isEmpty()) {
                        resultNode = node;
                    }
                } else {
                    // Second pass: Take node as is (already processed in map)
                    resultNode = node;
                    break;
                }
            }
            
            if (pass == 1) {
                // Create new node if none found with edges
                if (resultNode == null) {
                    resultNode = new Node(key.get());
                }
                resultNode.setMass(totalMass);
            }
            
            output.collect(key, resultNode.getLine());
        }
    }
    
    public int run(String[] args) throws Exception {
        // Parse command line arguments
        for (int i = 0; i < args.length; i++) {
            if ("-N".equals(args[i])) {
                totalNodes = Integer.parseInt(args[++i]);
            } else if ("-alpha".equals(args[i])) {
                alpha = Double.parseDouble(args[++i]);
            } else if ("-i".equals(args[i])) {
                iterations = Integer.parseInt(args[++i]);
            }
        }
        
        int iterationCount = 0;
        while (iterationCount < iterations) {
            String input = (iterationCount == 0) ? "input-graph" : "output-graph-" + iterationCount;
            missingMass = 0.0;
            
            // First pass
            pass = 1;
            String tempOutput = "output-graph-" + (iterationCount + 1) + "-temp";
            JobConf conf1 = getJobConf(args);
            FileInputFormat.setInputPaths(conf1, new Path(input));
            FileOutputFormat.setOutputPath(conf1, new Path(tempOutput));
            JobClient.runJob(conf1);
            
            // Second pass
            pass = 2;
            String finalOutput = "output-graph-" + (iterationCount + 1);
            JobConf conf2 = getJobConf(args);
            FileInputFormat.setInputPaths(conf2, new Path(tempOutput));
            FileOutputFormat.setOutputPath(conf2, new Path(finalOutput));
            JobClient.runJob(conf2);
            
            iterationCount++;
        }
        
        return 0;
    }
    
    private JobConf getJobConf(String[] args) {
        JobConf conf = new JobConf(getConf(), PageRank.class);
        conf.setJobName("pagerank-" + pass);
        
        conf.setOutputKeyClass(IntWritable.class);
        conf.setOutputValueClass(Text.class);
        
        conf.setMapperClass(MapClass.class);
        conf.setReducerClass(Reduce.class);
        
        return conf;
    }
    
    public static void main(String[] args) throws Exception {
        int res = ToolRunner.run(new Configuration(), new PageRank(), args);
        System.exit(res);
    }
}